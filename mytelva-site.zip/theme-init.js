try{var c=localStorage.getItem("mt_theme")||"dark";var d=c==="system"?matchMedia("(prefers-color-scheme: dark)").matches:c==="dark";document.documentElement.classList.toggle("dark",d)}catch(e){}
