// MyTelva — service worker (application installable, page hors ligne)
// Règle d'or : seuls les fichiers de base sont mis en cache (accueil, CSS, JS, logo, icônes).
// JAMAIS de cache pour les appels API (Supabase : autre domaine, jamais intercepté), les SMS, les codes,
// les numéros, les soldes ni les paiements : ces pages et données viennent toujours du serveur, en direct.
const CACHE = 'mt-v3'
const CORE = ['/', '/offline.html', '/manifest.webmanifest', '/icons/icon-192.png', '/icons/icon-512.png',
  '/icons/icon-maskable-512.png', '/icons/apple-touch-icon.png', '/icons/favicon-32.png', '/theme-init.js']
// Fichiers statiques autorisés en cache : JS/CSS construits (noms à empreinte), icônes, logo
const STATIC = /^\/(assets\/[\w.-]+\.(js|css|woff2?)|icons\/[\w.-]+\.png|brand\/[\w.-]+\.(png|svg)|theme-init\.js|manifest\.webmanifest|offline\.html)$/

self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(CACHE).then((c) => c.addAll(CORE)).then(() => self.skipWaiting()))
})
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k.startsWith('mt-') && k !== CACHE).map((k) => caches.delete(k))))
    .then(() => self.clients.claim()))
})
self.addEventListener('fetch', (e) => {
  const req = e.request
  if (req.method !== 'GET') return
  const url = new URL(req.url)
  if (url.origin !== self.location.origin) return // Supabase, prestataires de paiement… : jamais touchés
  // Pages : toujours le réseau d'abord. Hors ligne : la page d'accueil gardée, sinon la page « hors ligne ».
  if (req.mode === 'navigate') {
    e.respondWith(fetch(req).then((res) => {
      if (res.ok && url.pathname === '/') { const c = res.clone(); caches.open(CACHE).then((x) => x.put('/', c)) }
      return res
    }).catch(async () => (url.pathname === '/' && await caches.match('/')) || caches.match('/offline.html')))
    return
  }
  if (!STATIC.test(url.pathname)) return // tout le reste (vidéos, images, données) passe en direct
  e.respondWith(caches.match(req).then((hit) => hit || fetch(req).then((res) => {
    if (res.ok && res.type === 'basic') { const c = res.clone(); caches.open(CACHE).then((x) => x.put(req, c)) }
    return res
  })))
})

// Notifications sur téléphone (administration) : visiteur arrivé, nouveau message
self.addEventListener('push', (e) => {
  let d = {}
  try { d = e.data ? e.data.json() : {} } catch { d = { title: 'MyTelva', body: e.data ? e.data.text() : '' } }
  e.waitUntil(self.registration.showNotification(d.title || 'MyTelva', {
    body: d.body || '', icon: '/icons/icon-192.png', badge: '/icons/icon-192.png', tag: d.tag || 'mytelva', renotify: true, data: { url: d.url || '/admin?tab=discussions' },
  }))
})
self.addEventListener('notificationclick', (e) => {
  e.notification.close()
  const url = new URL(e.notification.data?.url || '/', self.location.origin).href
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then((list) => {
    for (const c of list) if (c.url.startsWith(self.location.origin) && 'focus' in c) { c.navigate(url); return c.focus() }
    return self.clients.openWindow(url)
  }))
})
